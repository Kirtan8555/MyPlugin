<?php

namespace MyPlugin;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getLogger()->info("MyPlugin Enabled!");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $player->sendMessage("§aWelcome to the server, " . $player->getName() . "!");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "hello") {
            if ($sender instanceof Player) {
                $sender->sendMessage("§bHello, " . $sender->getName() . "!");
                return true;
            }
        }
        return false;
    }
}